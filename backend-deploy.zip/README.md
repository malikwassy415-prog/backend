﻿# FirstPay Play: Backend Deployment Package

This standalone package contains the complete Fastify backend API, Prisma database schema, and provably fair game engine.

## Quick Start on Render, Railway, or VPS:

1. **Install dependencies:**
   ```bash
   npm install
   ```
   *(or `pnpm install`)*

2. **Generate database client & apply migrations:**
   ```bash
   npx prisma generate
   npx prisma migrate deploy
   ```

3. **Start the server:**
   ```bash
   npm start
   ```
   *(Runs `node dist/main.js`)*

## Required Environment Variables:
- `DATABASE_URL` = Your PostgreSQL connection string
- `REDIS_URL` = Your Redis connection string
- `JWT_ACCESS_SECRET` = Random string (32+ characters)
- `JWT_REFRESH_SECRET` = Random string (32+ characters)
- `NODE_ENV` = `production`
- `REAL_MONEY_ENABLED` = `false`
- `ALLOWED_ORIGINS` = Your frontend website URL
